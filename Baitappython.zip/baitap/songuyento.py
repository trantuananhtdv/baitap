<?xml version="1.0"?>
<flowgorithm fileversion="2.11">
    <attributes>
        <attribute name="name" value=""/>
        <attribute name="authors" value="Admin"/>
        <attribute name="about" value=""/>
        <attribute name="saved" value="2019-03-12 07:35:02 PM"/>
        <attribute name="created" value="QWRtaW47QURNSU4tUEM7MjAxOS0wMy0xMjswNzoyOTo0NSBQTTsyMzMx"/>
        <attribute name="edited" value="QWRtaW47QURNSU4tUEM7MjAxOS0wMy0xMjswNzozNTowMiBQTTsxOzI0Mjk="/>
    </attributes>
    <function name="Main" type="None" variable="">
        <parameters/>
        <body>
            <declare name="n" type="Integer" array="False" size=""/>
            <output expression="&quot;enter number&quot;" newline="True"/>
            <input variable="n"/>
            <declare name="c" type="Integer" array="False" size=""/>
            <declare name="p" type="Boolean" array="False" size=""/>
            <assign variable="p" expression="True"/>
            <for variable="c" start="2" end="n-1" direction="inc" step="1">
                <if expression="n % c ==0">
                    <then>
                        <assign variable="p" expression="False"/>
                    </then>
                    <else/>
                </if>
            </for>
            <output expression="&quot;prime&quot;" newline="True"/>
        </body>
    </function>
</flowgorithm>
