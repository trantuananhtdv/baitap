<?xml version="1.0"?>
<flowgorithm fileversion="2.11">
    <attributes>
        <attribute name="name" value=""/>
        <attribute name="authors" value="Admin"/>
        <attribute name="about" value=""/>
        <attribute name="saved" value="2019-03-11 08:50:51 PM"/>
        <attribute name="created" value="QWRtaW47QURNSU4tUEM7MjAxOS0wMy0xMTswODozODo0NSBQTTsyMzMx"/>
        <attribute name="edited" value="QWRtaW47QURNSU4tUEM7MjAxOS0wMy0xMTswODo1MDo1MSBQTTsxOzI0MzA="/>
    </attributes>
    <function name="Main" type="None" variable="">
        <parameters/>
        <body>
            <declare name="a" type="Integer" array="False" size=""/>
            <declare name="b" type="Integer" array="False" size=""/>
            <declare name="x" type="Integer" array="False" size=""/>
            <output expression="&quot;enter number a&quot;" newline="True"/>
            <input variable="a"/>
            <output expression="&quot;enter number b&quot;" newline="True"/>
            <input variable="b"/>
            <if expression="a=0">
                <then>
                    <if expression="b=0">
                        <then>
                            <output expression="&quot;The equation has a multitude of solutions&quot;" newline="True"/>
                        </then>
                        <else>
                            <output expression="&quot;The equation has no solution&quot;" newline="True"/>
                        </else>
                    </if>
                </then>
                <else>
                    <if expression="b=0">
                        <then>
                            <output expression="&quot;x=0&quot;" newline="True"/>
                        </then>
                        <else>
                            <assign variable="x" expression="-b/a"/>
                            <output expression="&quot;x=&quot;&amp; x" newline="True"/>
                        </else>
                    </if>
                </else>
            </if>
        </body>
    </function>
</flowgorithm>
