print("hello, world")
print("hoàng quốc đạt, 1755251030100007")